// =============================================
// SCHULPORTAL · viewer.js
// PDF-Anzeige & Navigation
// =============================================

document.addEventListener('DOMContentLoaded', () => {
  const homeView    = document.getElementById('home-view');
  const viewerView  = document.getElementById('viewer-view');
  const backBtn     = document.getElementById('back-btn');
  const publishBtn  = document.getElementById('publish-btn');
  const pdfFrame    = document.getElementById('pdf-frame');
  const pdfFallback = document.getElementById('pdf-fallback');
  const pdfDlLink   = document.getElementById('pdf-download-link');
  const viewerTitle = document.getElementById('viewer-title');
  const viewerAuthor= document.getElementById('viewer-author');
  const viewerDate  = document.getElementById('viewer-date');

  // Artikel im PDF-Viewer öffnen
  function openArticle(article) {
    const pdfPath = `pdfs/${article.datei}`;

    // Metadaten setzen
    viewerTitle.textContent  = article.titel || '—';
    viewerAuthor.textContent = article.autor  || '—';
    viewerDate.textContent   = window.SP_Main.formatDate(article.datum);
    pdfDlLink.href           = pdfPath;
    pdfDlLink.download       = article.datei;

    // PDF laden
    pdfFallback.style.display = 'none';
    pdfFrame.style.display    = 'block';
    pdfFrame.src              = pdfPath;

    // Fallback nach Timeout (wenn PDF nicht laden kann)
    const fallbackTimer = setTimeout(() => {
      if (!pdfFrame.contentDocument) {
        showFallback(pdfPath);
      }
    }, 5000);

    pdfFrame.onload = () => clearTimeout(fallbackTimer);
    pdfFrame.onerror = () => {
      clearTimeout(fallbackTimer);
      showFallback(pdfPath);
    };

    // Ansicht wechseln
    homeView.classList.remove('active');
    viewerView.classList.add('active');

    // Header anpassen
    backBtn.style.display   = 'inline-flex';
    publishBtn.style.display = 'none';
    document.getElementById('logo-area').style.display = 'none';

    // Suche verstecken
    if (window.SP_Search) window.SP_Search.hideSearch();

    // URL-Hash setzen (für Browser-Zurück-Button)
    const safeId = encodeURIComponent(article.datei.replace('.pdf', ''));
    history.pushState({ view: 'article', datei: article.datei }, '', `#artikel/${safeId}`);

    // Zum Seitenanfang scrollen
    window.scrollTo({ top: 0, behavior: 'smooth' });

    // Titel-Tag aktualisieren
    document.title = `${article.titel} · Schulportal`;
  }

  function showFallback(pdfPath) {
    pdfFrame.style.display    = 'none';
    pdfFallback.style.display = 'flex';
    pdfDlLink.href             = pdfPath;
  }

  // Zurück zur Startseite
  function goHome() {
    viewerView.classList.remove('active');
    homeView.classList.add('active');

    backBtn.style.display   = 'none';
    publishBtn.style.display = 'inline-flex';
    document.getElementById('logo-area').style.display = 'flex';

    // PDF entladen
    pdfFrame.src = '';

    // Suche wiederherstellen
    if (window.SP_Search) window.SP_Search.showSearch();

    // URL-Hash leeren
    history.pushState({ view: 'home' }, '', window.location.pathname);

    // Titel zurücksetzen
    document.title = 'Schulportal';
  }

  // Zurück-Button
  backBtn.addEventListener('click', goHome);

  // Browser-Zurück-Button (popstate)
  window.addEventListener('popstate', (e) => {
    if (e.state && e.state.view === 'home') {
      goHome();
    } else if (!e.state || e.state.view === 'home') {
      goHome();
    }
  });

  // Öffentliche API
  window.SP_Viewer = { openArticle, goHome };
});
