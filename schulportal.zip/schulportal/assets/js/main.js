// =============================================
// SCHULPORTAL · main.js
// Lädt articles.json und befüllt die Startseite
// =============================================

// Globaler Artikel-Speicher
window.SP = {
  allArticles: [],
  filteredArticles: [],
};

// Datum formatieren: "2025-03-10" → "10. März 2025"
function formatDate(dateStr) {
  if (!dateStr) return '—';
  const months = [
    'Januar','Februar','März','April','Mai','Juni',
    'Juli','August','September','Oktober','November','Dezember'
  ];
  const [year, month, day] = dateStr.split('-');
  return `${parseInt(day)}. ${months[parseInt(month) - 1]} ${year}`;
}

// Initiale aus dem Autorennamen
function getInitial(name) {
  if (!name) return '?';
  return name.trim().charAt(0).toUpperCase();
}

// Einzelne Artikel-Karte erstellen
function createCard(article, index) {
  const card = document.createElement('div');
  card.className = 'article-card';
  card.style.animationDelay = `${index * 0.06}s`;
  card.setAttribute('role', 'article');
  card.setAttribute('tabindex', '0');
  card.setAttribute('aria-label', `Artikel: ${article.titel}`);

  card.innerHTML = `
    <div class="card-tag">Artikel</div>
    <h2 class="card-title">${escapeHtml(article.titel)}</h2>
    <div class="card-meta">
      <span class="card-author" data-initial="${getInitial(article.autor)}"
            style="--initial: '${getInitial(article.autor)}'">
        ${escapeHtml(article.autor)}
      </span>
      <span class="card-date">${formatDate(article.datum)}</span>
    </div>
    <div class="card-footer">
      <button class="btn btn-open" data-datei="${escapeHtml(article.datei)}">
        <span>PDF öffnen</span>
        <span class="btn-icon" style="font-size:12px">→</span>
      </button>
    </div>
  `;

  // Card author initial via pseudo-element workaround
  const authorEl = card.querySelector('.card-author');
  authorEl.style.cssText += `position: relative; padding-left: 30px;`;

  // Override the ::before with actual initial via a span
  authorEl.innerHTML = `
    <span style="
      display:inline-flex;width:22px;height:22px;border-radius:50%;
      background:linear-gradient(135deg,#0D3B6E,#1A6B50);
      align-items:center;justify-content:center;
      font-size:10px;font-weight:700;color:#40C4FF;
      flex-shrink:0;margin-right:6px;
    ">${getInitial(article.autor)}</span>
    ${escapeHtml(article.autor)}
  `;

  // Klick auf Karte oder Button → PDF öffnen
  card.addEventListener('click', (e) => {
    window.SP_Viewer.openArticle(article);
  });

  // Keyboard-Navigation
  card.addEventListener('keydown', (e) => {
    if (e.key === 'Enter' || e.key === ' ') {
      e.preventDefault();
      window.SP_Viewer.openArticle(article);
    }
  });

  return card;
}

// HTML escapen für sichere Ausgabe
function escapeHtml(str) {
  if (!str) return '';
  return str
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#39;');
}

// Grid mit Artikeln befüllen
function renderArticles(articles) {
  const grid = document.getElementById('article-grid');
  const emptyState = document.getElementById('empty-state');
  const count = document.getElementById('article-count');

  grid.innerHTML = '';

  if (articles.length === 0) {
    emptyState.style.display = 'block';
    grid.style.display = 'none';
    count.textContent = '0 Beiträge';
    return;
  }

  emptyState.style.display = 'none';
  grid.style.display = 'grid';
  count.textContent = `${articles.length} ${articles.length === 1 ? 'Beitrag' : 'Beiträge'}`;

  articles.forEach((article, i) => {
    grid.appendChild(createCard(article, i));
  });
}

// articles.json laden
async function loadArticles() {
  const loadingState = document.getElementById('loading-state');
  const grid = document.getElementById('article-grid');

  try {
    const response = await fetch('data/articles.json');
    if (!response.ok) throw new Error(`HTTP ${response.status}`);

    const data = await response.json();
    const articles = data.articles || [];

    // Sortiert nach Datum (neueste zuerst)
    articles.sort((a, b) => new Date(b.datum) - new Date(a.datum));

    window.SP.allArticles = articles;
    window.SP.filteredArticles = [...articles];

    loadingState.style.display = 'none';
    renderArticles(articles);

  } catch (err) {
    loadingState.style.display = 'none';
    grid.style.display = 'none';

    const emptyState = document.getElementById('empty-state');
    emptyState.style.display = 'block';
    emptyState.querySelector('.empty-icon').textContent = '⚠️';
    emptyState.querySelector('.empty-title').textContent = 'Fehler beim Laden';
    emptyState.querySelector('.empty-sub').textContent =
      'Die Artikeldaten konnten nicht geladen werden. Prüfe die Datei data/articles.json.';

    console.error('[Schulportal] Fehler beim Laden von articles.json:', err);
  }
}

// Expose für andere Module
window.SP_Main = { renderArticles, formatDate, escapeHtml };

// Start
document.addEventListener('DOMContentLoaded', loadArticles);
