// =============================================
// SCHULPORTAL · search.js
// Echtzeit-Filterung der Artikel-Karten
// =============================================

document.addEventListener('DOMContentLoaded', () => {
  const searchInput  = document.getElementById('search-input');
  const searchClear  = document.getElementById('search-clear');
  const searchStatus = document.getElementById('search-status');

  let debounceTimer = null;

  // Suche ausführen
  function performSearch(query) {
    const q = query.trim().toLowerCase();

    // Clear-Button zeigen/verstecken
    searchClear.style.display = q.length > 0 ? 'flex' : 'none';

    if (q.length === 0) {
      // Alle Artikel anzeigen
      window.SP.filteredArticles = [...window.SP.allArticles];
      searchStatus.style.display = 'none';
      window.SP_Main.renderArticles(window.SP.filteredArticles);
      return;
    }

    // Filtern nach Titel oder Autor
    const results = window.SP.allArticles.filter(article => {
      const inTitle  = (article.titel  || '').toLowerCase().includes(q);
      const inAuthor = (article.autor  || '').toLowerCase().includes(q);
      return inTitle || inAuthor;
    });

    window.SP.filteredArticles = results;

    // Status-Text aktualisieren
    searchStatus.textContent =
      results.length === 0
        ? `Keine Treffer für „${query}"`
        : `${results.length} ${results.length === 1 ? 'Treffer' : 'Treffer'} für „${query}"`;
    searchStatus.style.display = 'inline-block';

    window.SP_Main.renderArticles(results);
  }

  // Input-Event mit Debounce (150ms)
  searchInput.addEventListener('input', () => {
    clearTimeout(debounceTimer);
    debounceTimer = setTimeout(() => {
      performSearch(searchInput.value);
    }, 150);
  });

  // Enter-Taste: sofort suchen
  searchInput.addEventListener('keydown', (e) => {
    if (e.key === 'Enter') {
      clearTimeout(debounceTimer);
      performSearch(searchInput.value);
    }
    // Escape: Suche leeren
    if (e.key === 'Escape') {
      clearSearch();
    }
  });

  // Clear-Button
  searchClear.addEventListener('click', clearSearch);

  function clearSearch() {
    searchInput.value = '';
    performSearch('');
    searchInput.focus();
  }

  // Im PDF-Viewer die Suchleiste ausblenden
  window.SP_Search = {
    hideSearch: () => { document.getElementById('header-center').style.visibility = 'hidden'; },
    showSearch: () => { document.getElementById('header-center').style.visibility = 'visible'; clearSearch(); },
  };
});
