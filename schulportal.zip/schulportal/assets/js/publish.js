// =============================================
// SCHULPORTAL · publish.js
// Modal zum Generieren des JSON-Eintrags
// =============================================

document.addEventListener('DOMContentLoaded', () => {
  const publishBtn   = document.getElementById('publish-btn');
  const modalOverlay = document.getElementById('modal-overlay');
  const modalClose   = document.getElementById('modal-close');
  const jsonOutput   = document.getElementById('json-output');
  const copyBtn      = document.getElementById('copy-btn');

  const formTitle    = document.getElementById('form-title');
  const formAuthor   = document.getElementById('form-author');
  const formDate     = document.getElementById('form-date');
  const formFile     = document.getElementById('form-file');

  // Datum auf heute setzen
  const today = new Date().toISOString().split('T')[0];
  formDate.value = today;

  // JSON live generieren
  function updateJsonOutput() {
    const titel = formTitle.value.trim();
    const autor = formAuthor.value.trim();
    const datum = formDate.value;
    const datei = formFile.value.trim();

    if (!titel && !autor && !datei) {
      jsonOutput.textContent = '← Fülle die Felder aus';
      jsonOutput.style.color = 'var(--col-text-dim)';
      return;
    }

    const entry = {
      titel: titel || '…',
      autor: autor || '…',
      datum: datum || today,
      datei: datei || 'dateiname.pdf',
    };

    jsonOutput.textContent = JSON.stringify(entry, null, 2);
    jsonOutput.style.color = 'var(--col-mint)';
  }

  [formTitle, formAuthor, formDate, formFile].forEach(el => {
    el.addEventListener('input', updateJsonOutput);
  });

  // Modal öffnen
  publishBtn.addEventListener('click', () => {
    modalOverlay.style.display = 'flex';
    document.body.style.overflow = 'hidden';
    setTimeout(() => formTitle.focus(), 100);
    updateJsonOutput();
  });

  // Modal schliessen
  function closeModal() {
    modalOverlay.style.display = 'none';
    document.body.style.overflow = '';
  }

  modalClose.addEventListener('click', closeModal);

  // Klick ausserhalb des Modals
  modalOverlay.addEventListener('click', (e) => {
    if (e.target === modalOverlay) closeModal();
  });

  // Escape-Taste
  document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape' && modalOverlay.style.display === 'flex') {
      closeModal();
    }
  });

  // JSON kopieren
  copyBtn.addEventListener('click', async () => {
    const text = jsonOutput.textContent;
    if (!text || text === '← Fülle die Felder aus') return;

    try {
      await navigator.clipboard.writeText(text);
      copyBtn.textContent = '✓ Kopiert!';
      copyBtn.classList.add('copied');
      setTimeout(() => {
        copyBtn.innerHTML = `
          <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round">
            <rect x="9" y="9" width="13" height="13" rx="2"/><path d="M5 15H4a2 2 0 01-2-2V4a2 2 0 012-2h9a2 2 0 012 2v1"/>
          </svg>
          Kopieren
        `;
        copyBtn.classList.remove('copied');
      }, 2000);
    } catch {
      // Fallback für ältere Browser
      const textarea = document.createElement('textarea');
      textarea.value = text;
      textarea.style.position = 'fixed';
      textarea.style.opacity = '0';
      document.body.appendChild(textarea);
      textarea.select();
      document.execCommand('copy');
      document.body.removeChild(textarea);
      copyBtn.textContent = '✓ Kopiert!';
      setTimeout(() => { copyBtn.textContent = 'Kopieren'; }, 2000);
    }
  });
});
